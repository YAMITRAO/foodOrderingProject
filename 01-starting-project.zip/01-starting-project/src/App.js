import Project from "./Component/Project";

function App() {
  return (
    <div>
      <Project />
    </div>
  );
}

export default App;
