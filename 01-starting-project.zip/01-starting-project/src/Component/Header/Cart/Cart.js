import "./Cart.css"

const Cart = ( ) => {

    return (
        <div className="cartContainer">
            <div className="cartSymbol"> $
             </div>
            <div className="cartHeading">Your Cart</div>
            <div className="cartCount">0</div>
        </div>
    )
}


export default Cart