import Navbar from "./Header/NavBar/Navbar";


const Project = () => {

    return(
        <>
        <Navbar />
        </>
    );
}

export default Project;