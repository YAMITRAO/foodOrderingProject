import Navbar from "./Header/NavBar/Navbar";
import Summary from "./Middle/Summary/Summary";


const Project = () => {

    return(
        <>
        <Navbar />
        <Summary />
        </>
    );
}

export default Project;